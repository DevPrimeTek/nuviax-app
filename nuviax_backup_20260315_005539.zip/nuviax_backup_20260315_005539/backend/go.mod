module github.com/devprimetek/nuviax-app

go 1.22

require (
	github.com/gofiber/fiber/v2 v2.52.5
	github.com/golang-jwt/jwt/v5 v5.2.1
	github.com/jackc/pgx/v5 v5.6.0
	github.com/redis/go-redis/v9 v9.5.3
	github.com/google/uuid v1.6.0
	golang.org/x/crypto v0.24.0
	github.com/go-playground/validator/v10 v10.22.0
	github.com/pquerna/otp v1.4.0
	github.com/robfig/cron/v3 v3.0.1
	go.uber.org/zap v1.27.0
	github.com/joho/godotenv v1.5.1
	github.com/boombuler/barcode v1.0.1
)
